<?php

declare(strict_types=1);

namespace Saloon\Exceptions\Request\Statuses;

use Saloon\Exceptions\Request\ServerException;

class InternalServerErrorException extends ServerException
{
    //
}
